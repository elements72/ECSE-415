The library used are:
- Scipy
- Opencv
- Numpy
- Matplotlib
The test image used for exercise 3.2 it is also present.